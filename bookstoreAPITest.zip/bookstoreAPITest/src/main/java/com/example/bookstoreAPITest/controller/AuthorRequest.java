package com.example.bookstoreAPITest.controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AuthorRequest {
    private String authorName;
    private Date authorBirthday;

    public AuthorRequest() {
    }

    public AuthorRequest(String authorName, Date authorBirthday) {
        this.authorName = authorName;
        this.authorBirthday = authorBirthday;
    }

    public String getName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Date getAuthorBirthday() {
        return authorBirthday;
    }

    public void setAuthorBirthday(Date authorBirthday) {
        this.authorBirthday = authorBirthday;
    }
}
