package com.example.bookstoreAPITest.controller;


import com.example.bookstoreAPITest.dto.AuthorResponse;
import com.example.bookstoreAPITest.dto.BookResponse;
import com.example.bookstoreAPITest.model.Author;
import com.example.bookstoreAPITest.model.Book;
import com.example.bookstoreAPITest.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/{isbn}")
    public ResponseEntity<BookResponse> getBookByIsbn(@PathVariable String isbn) {
        Book book = bookService.getBookByIsbn(isbn);
        if (book != null) {
            BookResponse bookResponse = convertToBookResponse(book);
            return ResponseEntity.ok(bookResponse);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping
    public ResponseEntity<List<BookResponse>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        List<BookResponse> bookResponses = books.stream()
                .map(this::convertToBookResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(bookResponses);
    }

    private BookResponse convertToBookResponse(Book book) {
        List<AuthorResponse> authorResponses = book.getAuthors().stream()
                .map(author -> new AuthorResponse(author.getId(), author.getName(), author.getBirthday()))
                .collect(Collectors.toList());

        return new BookResponse(
                book.getIsbn(),
                book.getTitle(),
                book.getYear(),
                book.getPrice(),
                book.getGenre(),
                authorResponses
        );
    }
    @PostMapping
    public ResponseEntity<BookResponse> createBook(@RequestBody BookRequest bookRequest) {
        Book createdBook = bookService.createBook(bookRequest);
        BookResponse bookResponse = convertToBookResponse(createdBook);
        return ResponseEntity.status(HttpStatus.CREATED).body(bookResponse);
    }

    @PutMapping("/{isbn}")
    public ResponseEntity<BookResponse> updateBook(@PathVariable String isbn, @RequestBody BookRequest bookRequest) {
        Book existingBook = bookService.getBookByIsbn(isbn);
        if (existingBook != null) {
            existingBook.setTitle(bookRequest.getTitle());
            existingBook.setYear(bookRequest.getYear());
            existingBook.setPrice(bookRequest.getPrice());
            existingBook.setGenre(bookRequest.getGenre());

            // Update the author details if needed
            Author author = existingBook.getAuthors().get(0);
            author.setName(bookRequest.getAuthorName());
            author.setBirthday(bookRequest.getAuthorBirthday());

            Book updatedBook = bookService.updateBook(isbn, existingBook);
            BookResponse bookResponse = convertToBookResponse(updatedBook);
            return ResponseEntity.ok(bookResponse);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found with ISBN: " + isbn);
        }
    }

    @DeleteMapping("/{isbn}")
    public ResponseEntity<Void> deleteBook(@PathVariable String isbn) {
        boolean deleted = bookService.deleteBook(isbn);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<BookResponse>> searchBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String authorName) {
        List<Book> books = bookService.searchBooks(title, authorName);
        List<BookResponse> bookResponses = books.stream()
                .map(this::convertToBookResponse)
                .collect(Collectors.toList());

        if (title != null) {
            bookResponses = bookResponses.stream()
                    .filter(bookResponse -> bookResponse.getTitle().equals(title))
                    .collect(Collectors.toList());
        }

        if (authorName != null) {
            bookResponses = bookResponses.stream()
                    .filter(bookResponse ->
                            bookResponse.getAuthors().stream()
                                    .anyMatch(authorResponse ->
                                            authorResponse.getName().equals(authorName)))
                    .collect(Collectors.toList());
        }

        return ResponseEntity.ok(bookResponses);
    }

}
