package com.example.bookstoreAPITest.service;

import com.example.bookstoreAPITest.model.Author;
import com.example.bookstoreAPITest.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AuthorService {
    private final AuthorRepository authorRepository;

    @Autowired
    public AuthorService(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }

    public Optional<Author> getAuthorById(int id) {
        return authorRepository.findById(id);
    }

    public Author createAuthor(Author author) {
        return authorRepository.save(author);
    }

    public Author updateAuthor(int id, Author author) {
        Optional<Author> existingAuthor = authorRepository.findById(id);
        if (existingAuthor.isPresent()) {
            author.setId(id);
            return authorRepository.save(author);
        } else {
            throw new IllegalArgumentException("Author not found with ID: " + id);
        }
    }

    public void deleteAuthor(int id) {
        authorRepository.deleteById(id);
    }
}
