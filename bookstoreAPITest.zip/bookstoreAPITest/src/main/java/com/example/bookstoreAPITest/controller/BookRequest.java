package com.example.bookstoreAPITest.controller;

import com.example.bookstoreAPITest.model.Author;
import com.example.bookstoreAPITest.model.Book;

import java.util.*;

import java.util.List;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import java.util.List;

public class BookRequest {
    private String isbn;
    private String title;
    private int year;
    private double price;
    private String genre;
    private List<AuthorRequest> authors;

    public BookRequest() {
    }

    public BookRequest(String isbn, String title, int year, double price, String genre, List<AuthorRequest> authors) {
        this.isbn = isbn;
        this.title = title;
        this.year = year;
        this.price = price;
        this.genre = genre;
        this.authors = authors;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<AuthorRequest> getAuthors() {
        return authors;
    }

    public void setAuthors(List<AuthorRequest> authors) {
        this.authors = authors;
    }
    private AuthorRequest authorRequest;

    // Other attributes...

    public void setAuthorRequest(AuthorRequest authorRequest) {
        this.authorRequest = authorRequest;
    }

    public String getAuthorName() {
        // Assuming there is only one author, retrieve the name from the first author in the list
        if (authors != null && !authors.isEmpty()) {
            return authors.get(0).getName();
        }
        return null;
    }

    public Date getAuthorBirthday() {
        if (authors != null && !authors.isEmpty()) {
            return authors.get(0).getAuthorBirthday();
        }
        return null;
    }
}
