package com.example.bookstoreAPITest.service;

import com.example.bookstoreAPITest.controller.AuthorRequest;
import com.example.bookstoreAPITest.controller.BookRequest;
import com.example.bookstoreAPITest.model.Author;
import com.example.bookstoreAPITest.model.Book;
import com.example.bookstoreAPITest.repository.BookRepository;
import com.example.bookstoreAPITest.repository.AuthorRepository;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.example.bookstoreAPITest.controller.AuthorRequest;
import com.example.bookstoreAPITest.model.Author;
import com.example.bookstoreAPITest.model.Book;
import com.example.bookstoreAPITest.repository.AuthorRepository;
import com.example.bookstoreAPITest.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    public Book getBookByIsbn(String isbn) {
        return bookRepository.findById(isbn).orElse(null);
    }

    public List<Book> searchBooks(String title, String authorName) {
        if (title != null && authorName != null) {
            // Search by both title and author name (exact match)
            return bookRepository.findByTitleAndAuthorsName(title, authorName);
        } else if (title != null) {
            // Search by title only (exact match)
            return bookRepository.findByTitle(title);
        } else if (authorName != null) {
            // Search by author name only (exact match)
            return bookRepository.findByAuthorsName(authorName);
        } else {
            // No search parameters provided, return all books
            return bookRepository.findAll();
        }
    }

    public Book createBook(BookRequest bookRequest) {
        // Create a new Book object
        Book book = new Book();
        book.setIsbn(bookRequest.getIsbn());
        book.setTitle(bookRequest.getTitle());
        book.setYear(bookRequest.getYear());
        book.setPrice(bookRequest.getPrice());
        book.setGenre(bookRequest.getGenre());

        // Iterate over the authors in the request
        for (AuthorRequest authorRequest : bookRequest.getAuthors()) {
            // Create a new Author object
            Author author = new Author();
            author.setName(authorRequest.getName());

            // Set the birthday directly from the request
            author.setBirthday(authorRequest.getAuthorBirthday());

            // Save the Author object
            Author savedAuthor = authorRepository.save(author);

            // Add the Book to the Author's books list
            savedAuthor.getBooks().add(book);

            // Set the Author in the Book object
            book.getAuthors().add(savedAuthor);
        }

        // Save the Book object
        return bookRepository.save(book);
    }




    public Book updateBook(String isbn, Book updatedBook) {
        Optional<Book> existingBook = bookRepository.findById(isbn);
        if (existingBook.isPresent()) {
            Book book = existingBook.get();
            book.setTitle(updatedBook.getTitle());
            book.setYear(updatedBook.getYear());
            book.setPrice(updatedBook.getPrice());
            book.setGenre(updatedBook.getGenre());
            book.setAuthors(updatedBook.getAuthors());
            return bookRepository.save(book);
        } else {
            throw new IllegalArgumentException("Book not found with ISBN: " + isbn);
        }
    }
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }



    public boolean deleteBook(String isbn) {
        Optional<Book> existingBook = bookRepository.findById(isbn);
        if (existingBook.isPresent()) {
            bookRepository.deleteById(isbn);
            return true;
        } else {
            return false;
        }
    }
}